<?php

namespace App\Filament\Resources\ArticleEksternalResource\Pages;

use App\Filament\Resources\ArticleEksternalResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateArticleEksternal extends CreateRecord
{
    protected static string $resource = ArticleEksternalResource::class;
}
