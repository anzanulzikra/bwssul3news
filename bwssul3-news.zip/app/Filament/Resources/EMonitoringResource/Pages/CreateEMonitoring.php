<?php

namespace App\Filament\Resources\EMonitoringResource\Pages;

use App\Filament\Resources\EMonitoringResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateEMonitoring extends CreateRecord
{
    protected static string $resource = EMonitoringResource::class;
}
