<?php

namespace App\Filament\Resources\PartnersLogoResource\Pages;

use App\Filament\Resources\PartnersLogoResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePartnersLogo extends CreateRecord
{
    protected static string $resource = PartnersLogoResource::class;
}
