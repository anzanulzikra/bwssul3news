<?php

namespace App\Filament\Resources\PublikasiResource\Pages;

use App\Filament\Resources\PublikasiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePublikasi extends CreateRecord
{
    protected static string $resource = PublikasiResource::class;
}
