<?php

namespace App\Http\Controllers;

use App\Models\SliderWeb;
use App\Models\Article;
use App\Models\ArticleEksternal;
use App\Models\Publikasi;
use App\Models\EMonitoring;
use App\Models\PartnersLogo;
use App\Models\SettingWeb;
use App\Models\Category;
use App\Models\Gallery;
use App\Services\ArticleService;
use Illuminate\Http\Request;


class HomeController extends Controller
{
    public function __construct(
        private readonly ArticleService $articleService
    ) {}
    public function index()
    {
        // Hero carousel images
        $sliderWebs = SliderWeb::orderBy('order')->limit(10)->get();

        // Berita internal BWS (published only)
        $articles = Article::with(['category', 'tags'])
            ->where('status', 'published')
            ->whereRaw('CHAR_LENGTH(title) <=190')
            ->orderBy('published_at', 'desc')
            ->limit(10)
            ->get();

        // Berita Kementrian PU (artikel eksternal dengan kategori Kementrian PU)
        $articleKementrianPU = ArticleEksternal::with('category')
            ->whereHas('category', function($query) {
                $query->where('name', 'LIKE', '%Kementrian PU%')
                      ->orWhere('name', 'LIKE', '%Kementerian PU%');
            })
            ->where('status', 'published')
            ->whereRaw('CHAR_LENGTH(title) <=190')
            ->orderBy('published_at', 'desc')
            ->limit(10)
            ->get();

        // Berita SDA (artikel eksternal dengan kategori SDA)
        $articleSDA = ArticleEksternal::with('category')
            ->whereHas('category', function($query) {
                $query->where('name', 'SDA');
            })
            ->where('status', 'published')
            ->whereRaw('CHAR_LENGTH(title) <=190')
            ->orderBy('published_at', 'desc')
            ->limit(10)
            ->get();

        // Data untuk section video dan infografis
        $publikasis = Publikasi::orderBy('created_at', 'desc')->limit(10)->get();
        $eMonitorings = EMonitoring::orderBy('last_updated', 'desc')->limit(10)->get();
        $partnersLogos = PartnersLogo::orderBy('order')->limit(10)->get();
        $settingWebs = SettingWeb::orderBy('name')->limit(20)->get();

        return view('index', compact(
            'sliderWebs', 
            'articles', 
            'articleKementrianPU', 
            'articleSDA',
            'publikasis', 
            'eMonitorings', 
            'partnersLogos', 
            'settingWebs'
        ));
    }

    //Menampilkan halaman detail artikel
    public function articleDetail($slug)
    {
        // Ambil artikel berdasarkan slug (published only)
        $article = Article::with(['category', 'tags', 'images'])
            ->where('status', 'published')
            ->where('slug', $slug)
            ->firstOrFail();

        // Artikel terkait dari kategori yang sama (exclude artikel saat ini)
        $relatedArticles = Article::where('id', '!=', $article->id)
            ->where('status', 'published')
            ->whereRaw('CHAR_LENGTH(title) <=190')
            ->when($article->category_id, function ($query, $categoryId) {
                return $query->where('category_id', $categoryId);
            })
            ->orderBy('published_at', 'desc')
            ->limit(4)
            ->get();

        return view('article.detail', compact('article', 'relatedArticles'));
    }

    // Halaman listing artikel gabungan (Internal + Eksternal)
    public function articlesListing(Request $request)
    {
        $categoryFilter = $request->get('category', 'all');
        
        // Get filtered articles using service
        $articles = $this->articleService->getFilteredArticles($request);
        
        // Get categories for sidebar
        $categories = $this->articleService->getArticleCategories();

        return view('pages.content-listing', [
            'items' => $articles,
            'categories' => $categories,
            'activeCategory' => $categoryFilter,
            'contentType' => 'mixed',
            'pageTitle' => 'Berita',
            'pageSubtitle' => 'BWS Sulawesi III Palu',
            'breadcrumbTitle' => 'Berita',
            'sidebarTitle' => 'Kategori Berita',
            'totalItems' => $articles->total(),
            'title' => 'Berita - BWS Sulawesi III Palu'
        ]);
    }

    // Halaman listing artikel eksternal (Kementrian PU & SDA)
    public function externalArticlesListing(Request $request)
    {
        $query = ArticleEksternal::with(['category'])
            ->where('status', 'published');

        // Filter berdasarkan kategori
        if ($request->has('category') && $request->category !== 'all') {
            $query->whereHas('category', function($q) use ($request) {
                $q->where('slug', $request->category);
            });
        }

        // Filter berdasarkan pencarian
        if ($request->has('search') && $request->search) {
            $query->where(function($q) use ($request) {
                $q->where('title', 'like', '%' . $request->search . '%')
                  ->orWhereHas('category', function($catQuery) use ($request) {
                      $catQuery->where('name', 'like', '%' . $request->search . '%');
                  });
            });
        }

        $articles = $query->orderBy('published_at', 'desc')->paginate(12);

        // Dapatkan kategori untuk sidebar
        $categories = [
            ['name' => 'Semua Berita', 'slug' => 'all']
        ];
        
        $externalCategories = Category::whereHas('articleEksternals', function($q) {
            $q->where('status', 'published');
        })->get();
        
        foreach($externalCategories as $category) {
            $categories[] = [
                'name' => $category->name,
                'slug' => $category->slug
            ];
        }

        return view('pages.content-listing', [
            'items' => $articles,
            'categories' => $categories,
            'activeCategory' => $request->get('category', 'all'),
            'contentType' => 'article-eksternal',
            'pageTitle' => 'Berita Eksternal',
            'pageSubtitle' => 'Kementrian PU & SDA',
            'breadcrumbTitle' => 'Berita Eksternal',
            'sidebarTitle' => 'Kategori Berita',
            'totalItems' => $articles->total(),
            'title' => 'Berita Eksternal - BWS Sulawesi III Palu'
        ]);
    }

    // Halaman listing gallery
    public function galleryListing(Request $request)
    {
        $query = Gallery::query();

        // Filter berdasarkan pencarian
        if ($request->has('search') && $request->search) {
            $query->where(function($q) use ($request) {
                $q->where('title', 'like', '%' . $request->search . '%')
                  ->orWhere('description', 'like', '%' . $request->search . '%');
            });
        }

        $galleries = $query->orderBy('created_at', 'desc')->paginate(12);

        // Kategori untuk gallery (bisa disesuaikan)
        $categories = [
            ['name' => 'Semua Gallery', 'slug' => 'all'],
            ['name' => 'Kegiatan', 'slug' => 'kegiatan'],
            ['name' => 'Fasilitas', 'slug' => 'fasilitas'],
            ['name' => 'Acara', 'slug' => 'acara']
        ];

        return view('pages.content-listing', [
            'items' => $galleries,
            'categories' => $categories,
            'activeCategory' => $request->get('category', 'all'),
            'contentType' => 'gallery',
            'pageTitle' => 'Gallery',
            'pageSubtitle' => 'Dokumentasi Kegiatan',
            'breadcrumbTitle' => 'Gallery',
            'sidebarTitle' => 'Kategori Gallery',
            'totalItems' => $galleries->total(),
            'title' => 'Gallery - BWS Sulawesi III Palu'
        ]);
    }

    // Halaman listing publikasi
    public function publikasiListing(Request $request)
    {
        $query = Publikasi::query();

        // Filter berdasarkan pencarian
        if ($request->has('search') && $request->search) {
            $query->where(function($q) use ($request) {
                $q->where('title', 'like', '%' . $request->search . '%')
                  ->orWhere('description', 'like', '%' . $request->search . '%');
            });
        }

        $publikasis = $query->orderBy('created_at', 'desc')->paginate(12);

        // Kategori untuk publikasi (bisa disesuaikan)
        $categories = [
            ['name' => 'Semua Publikasi', 'slug' => 'all'],
            ['name' => 'Laporan', 'slug' => 'laporan'],
            ['name' => 'Buku', 'slug' => 'buku'],
            ['name' => 'Jurnal', 'slug' => 'jurnal']
        ];

        return view('pages.content-listing', [
            'items' => $publikasis,
            'categories' => $categories,
            'activeCategory' => $request->get('category', 'all'),
            'contentType' => 'publikasi',
            'pageTitle' => 'Publikasi',
            'pageSubtitle' => 'Dokumen & Laporan',
            'breadcrumbTitle' => 'Publikasi',
            'sidebarTitle' => 'Kategori Publikasi',
            'totalItems' => $publikasis->total(),
            'title' => 'Publikasi - BWS Sulawesi III Palu'
        ]);
    }
}