<!-- Header Navigation -->
<header class="bg-white shadow-sm border-b border-gray-200">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center h-20">
            <!-- Logo Section -->
            <div class="flex items-center gap-3">
                <img src="{{ asset('assets/images/logo.png') }}" alt="Logo BWS Sulawesi III Palu" class="w-[250px] h-[42px] lg:w-[307px] lg:h-[52px] object-contain">
            </div>
            
            <!-- Navigation Menu -->
            <nav class="hidden md:flex items-center gap-8">
                <a href="{{ route('home') }}" class="text-blue-sda hover:text-blue-600 transition-colors">Beranda</a>
                <div class="relative group">
                    <button class="flex items-center gap-1 text-blue-sda hover:text-blue-600 transition-colors">
                        Profil
                        <img src="{{ asset('assets/icons/chevron-down.svg') }}" alt="Dropdown" class="w-4 h-4">
                    </button>
                </div>
                <div class="relative group">
                    <button class="flex items-center gap-1 text-blue-sda hover:text-blue-600 transition-colors">
                        Layanan
                        <img src="{{ asset('assets/icons/chevron-down.svg') }}" alt="Dropdown" class="w-4 h-4">
                    </button>
                </div>
                <a href="{{ route('articles.listing') }}" class="text-blue-sda hover:text-blue-600 transition-colors">Berita</a>
                <div class="relative group">
                    <button class="flex items-center gap-1 text-blue-sda hover:text-blue-600 transition-colors">
                        Informasi Publik
                        <img src="{{ asset('assets/icons/chevron-down.svg') }}" alt="Dropdown" class="w-4 h-4">
                    </button>
                </div>
                <div class="relative group">
                    <button class="flex items-center gap-1 text-blue-sda hover:text-blue-600 transition-colors">
                        Publikasi
                        <img src="{{ asset('assets/icons/chevron-down.svg') }}" alt="Dropdown" class="w-4 h-4">
                    </button>
                </div>
            </nav>
            
            <!-- Search Input -->
            <div class="hidden md:flex items-center">
                <form action="{{ route('articles.listing') }}" method="GET" class="w-[250px] h-[40px] px-2 py-2 bg-white rounded-lg border-2 border-yellow-500 flex items-center gap-2">
                    <img src="{{ asset('assets/icons/search.svg') }}" alt="Search" class="w-5 h-5">
                    <input type="text" 
                           name="search" 
                           placeholder="Cari Berita" 
                           class="w-full text-blue-sda text-sm font-normal outline-none pr-2"
                           onkeypress="handleSearchKeypress(event)">
                    <button type="submit" class="hidden">Search</button>
                </form>
            </div>
            
            <!-- Mobile Menu Button -->
            <button class="md:hidden text-blue-sda" id="mobileMenuBtn">
                <img src="{{ asset('assets/icons/menu.svg') }}" alt="Menu" class="w-6 h-6">
            </button>
        </div>
    </div>
</header>

<!-- Mobile Navigation Drawer -->
<div id="mobileMenu" class="fixed inset-0 z-50 bg-white flex flex-col p-8 space-y-8 transition-transform duration-300 transform -translate-x-full md:hidden">
    <button id="closeMobileMenu" class="self-end mb-8">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="w-8 h-8 text-blue-sda">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
        </svg>
    </button>
    <nav class="flex flex-col gap-6">
        <a href="{{ route('home') }}" class="text-blue-sda text-lg font-medium">Beranda</a>
        <a href="#" class="text-blue-sda text-lg font-medium">Profil</a>
        <a href="#" class="text-blue-sda text-lg font-medium">Layanan</a>
        
        <a href="{{ route('articles.listing') }}" class="text-blue-sda text-lg font-medium">Berita</a>
        
        <a href="#" class="text-blue-sda text-lg font-medium">Informasi Publik</a>
        <a href="#" class="text-blue-sda text-lg font-medium">Publikasi</a>
        
        <!-- Mobile Search -->
        <div class="mt-4 pt-4 border-t border-gray-200">
            <form action="{{ route('articles.listing') }}" method="GET" class="flex">
                <input type="text" 
                       name="search" 
                       placeholder="Cari Berita" 
                       class="flex-1 px-4 py-2 border-2 border-yellow-500 rounded-l-lg text-blue-sda text-sm outline-none focus:ring-2 focus:ring-yellow-300">
                <button type="submit" class="px-4 py-2 bg-yellow-accent text-blue-sda font-medium rounded-r-lg hover:bg-yellow-500 transition-colors border-2 border-yellow-accent border-l-0">
                    <img src="{{ asset('assets/icons/search.svg') }}" alt="Search" class="w-5 h-5">
                </button>
            </form>
        </div>
    </nav>
</div>

<script>
function handleSearchKeypress(event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        const form = event.target.closest('form');
        const searchValue = event.target.value.trim();
        
        if (searchValue) {
            form.submit();
        }
    }
}

// Toggle mobile dropdown menu
function toggleMobileDropdown(menuId) {
    const dropdown = document.getElementById(menuId + '-dropdown');
    const chevron = document.getElementById(menuId + '-chevron');
    
    if (dropdown.classList.contains('hidden')) {
        dropdown.classList.remove('hidden');
        chevron.style.transform = 'rotate(180deg)';
    } else {
        dropdown.classList.add('hidden');
        chevron.style.transform = 'rotate(0deg)';
    }
}

// Auto-focus search when clicking on search icon
document.addEventListener('DOMContentLoaded', function() {
    const searchIcons = document.querySelectorAll('img[alt="Search"]');
    searchIcons.forEach(function(icon) {
        icon.addEventListener('click', function() {
            const searchInput = this.nextElementSibling;
            if (searchInput && searchInput.tagName === 'INPUT') {
                searchInput.focus();
            }
        });
    });
});
</script>