{{-- Content Sidebar Component --}}
<aside class="w-full lg:w-[280px] order-1">
    <div class="bg-yellow-100 rounded-xl p-6 lg:sticky lg:top-6">
        <div class="space-y-6">
            <div>
                <h3 class="text-blue-sda font-semibold text-lg mb-4">{{ $sidebarTitle }}</h3>
                <div class="space-y-2">
                    @php
                        $currentType = null;
                        $isFirstInternalDisplayed = false;
                        $isFirstExternalDisplayed = false;
                    @endphp
                    
                    @foreach($categories as $category)
                        @if(isset($category['type']))
                            {{-- Show group headers --}}
                            @if($category['type'] === 'internal' && !$isFirstInternalDisplayed && $category['slug'] !== 'all' && $category['slug'] !== 'internal' && $category['slug'] !== 'external')
                                <div class="pt-2 pb-1">
                                    <h4 class="text-xs font-bold text-blue-sda opacity-70 uppercase tracking-wide pl-3">Internal</h4>
                                </div>
                                @php $isFirstInternalDisplayed = true; @endphp
                            @elseif($category['type'] === 'external' && !$isFirstExternalDisplayed && $category['slug'] !== 'all' && $category['slug'] !== 'internal' && $category['slug'] !== 'external')
                                <div class="pt-3 pb-1">
                                    <h4 class="text-xs font-bold text-blue-sda opacity-70 uppercase tracking-wide pl-3">External</h4>
                                </div>
                                @php $isFirstExternalDisplayed = true; @endphp
                            @endif
                        @endif
                        
                        {{-- Category item --}}
                        <div class="{{ $activeCategory === $category['slug'] ? 'bg-yellow-accent text-white' : 'text-blue-sda hover:bg-yellow-200' }} px-3 py-2 rounded-lg text-sm {{ $activeCategory === $category['slug'] ? 'font-medium' : '' }} cursor-pointer transition-colors 
                                   {{ in_array($category['slug'], ['all', 'internal', 'external']) ? '' : 'ml-3' }}"
                             onclick="filterByCategory('{{ $category['slug'] }}')">
                            {{ $category['name'] }}
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</aside>

@push('scripts')
<script>
function filterByCategory(categorySlug) {
    // Update URL dengan parameter kategori
    const url = new URL(window.location);
    if (categorySlug === 'all') {
        url.searchParams.delete('category');
    } else {
        url.searchParams.set('category', categorySlug);
    }
    url.searchParams.delete('page'); // Reset pagination saat filter berubah
    window.location.href = url.toString();
}
</script>
@endpush